import React from 'react'
import Layout from '../components/DefaultLayout'
import AddTask from '../components/task/AddTask'

const page = () => {
  return (
    <Layout>
      <AddTask/>
    </Layout>
  )
}

export default page